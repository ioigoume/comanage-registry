<?php

App::uses('AppController', 'Controller');

class LofarProvisionerAppController extends AppController {

}
